

<?php $__env->startSection('content'); ?>


        <div class="card-body container">
          <form action="/filter/" method="get" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-md-3">
                <label>Filter by Date</label>
                
                <input type="date" name="start_date" value="<?php echo e(old('start_date')); ?>" class="form-control">
                
                
                
    
              </div>
              <div class="col-md-3">
                <label>Filter by Date</label>
                
                <input type="date" name="end_date" value="<?php echo e(old('end_date')); ?>" class="form-control">
              </div>
              <div class="col-md-3">
                <label>Filter by Designation</label>
                <select name="status" class="form-select form-control" id="">
                  <option value="">Select Designation</option>
                  <option value="1">Assistant Programmer</option>
                  <option value="2">Assistant Maintenance Engineer</option>
                </select>
              </div>
              <div class="col-md-3">
                <label>Filter by Office</label>
                <select name="status" class="form-select form-control" id="">
                  <option value="">Select Designation</option>
                  <option value="1"></option>
                  <option value="2">Assistant Maintenance Engineer</option>
                </select>
              </div>
              <div class="col-md-3">
                <div class="row mt-4">
                  <div class="col-md-6">
                <button type="submit" class="btn btn-primary">Filter</button>
    
                  </div>
                  <div class="col-md-6">
                    <form action="/logout" method="POST">
                      <?php echo csrf_field(); ?>
                      <button type="submit" class="btn btn-danger">Logout</button>
                  </form>
                  </div>
                </div>
              </div>
              
            </div>
            
          </form>
        </div>
        <hr>
        <!-- Content for the right div -->
        <table style="width: 600px" class="table table-striped m-auto" >
          <thead>
            <tr>
              <th scope="col">ক্রমিক</th>
              <th scope="col">নাম</th>
              <th scope="col">পদবী</th>
              <th scope="col">অফিস</th>
              <th scope="col">জন্ম তারিখ</th>
              <th scope="col">পিআরএল</th>
              <th scope="col">বাসা নাম/নম্বর</th>
              <th scope="col">স্মারক নম্বর</th>
              <th scope="col">মন্তব্য</th>
            </tr>
          </thead>
          <tbody>
            
              <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <tr>
                  <th scope="row"><?php echo e($house->id); ?></th>
                  <td><?php echo e($house->name); ?></td>
                  <td><?php echo e($house->designation->designation); ?></td>
                  <td><?php echo e($house->office->office_name); ?></td>
                  <td><?php echo e($house->dob); ?></td>
                  <td><?php echo e($house->prl_date); ?></td>
                  <td><?php echo e($house->house_no_name); ?></td>
                  <td><?php echo e($house->reference_no); ?></td>
                  <td><?php echo e($house->comment); ?></td>
                  
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
        </table>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bashabari\resources\views/admin.blade.php ENDPATH**/ ?>