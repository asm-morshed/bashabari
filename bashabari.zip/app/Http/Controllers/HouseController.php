<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\House;

class HouseController extends Controller
{
    public function index(){
        // $employees = Employee::with('designation')->get();
        $house = House::with('designation')->get();
        return view('index')->with('houses',$house);
    }
    public function admin(){
        
        if(Auth::user()->email ==='ame@gmail.com')
        {
            $house = House::all();
            return view('admin')->with('houses',$house);
        }
       
    }
    public function filter(Request $request){
        // dd(Auth::user()->email);
        // dd($request->status);
        $start_date = $request->start_date;
        $end_date = $request->end_date;
        $status = $request->status;
        
        $query = House::query();
        if($start_date && $end_date){
            $query->whereDate('prl_date','>=',$start_date)
            ->whereDate('prl_date','<=',$end_date);
        }
        if($status){
            $query->where('designation_id', $status);
        }
        
        $house = $query->get();

        
        return view('index')->with('houses',$house,);

    }
}
