This is a simple laravel project based for my office to maintain allocated housed. This web based app is called "বাসাবাড়ি".

## The web application has some following tools:

- Laravel : Build different controller to communicate with Database and other Logic for the application
- Laravel Blade: This is for the frontend side
- MySQL: I've used MySQL database for this web application.

